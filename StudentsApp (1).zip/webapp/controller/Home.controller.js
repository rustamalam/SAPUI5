sap.ui.define([
	"ibm/fin/ar/controller/BaseController",
	"sap/m/MessageBox",
	"sap/m/MessageToast",
	"ibm/fin/ar/util/lifesaver"
], function(Controller, MessageBox, MessageToast, lifeSaver) {
	"use strict";

	return Controller.extend("ibm.fin.ar.controller.Home", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf ibm.fin.ar.view.Home
		 */
		formatter: lifeSaver,

		onInit: function() {
			debugger;
			var oRouter = this.getOwnerComponent().getRouter();
			//Whenever the route change, Its changed when browser back-forth or manually or select an item,
			oRouter.attachRoutePatternMatched(this.herculis, this);
			// var oJsonModel = this.getOwnerComponent().getModel("oJsonModel");
			this.getView().byId("btnShow").setVisible(false);
			this.getView().byId("btnSearch").setVisible(false);
			this.getView().byId("btnRegSave").setVisible(false);
			this.getView().byId("btnMassRegSave").setVisible(false);

			var oJsonModel = this.getOwnerComponent().getModel("oJsonModel");
			// oJsonModel.setProperty("/oMessage");
			// 	oJsonModel.setProperty("/StudentReg");
			// var oJsonModel = that.getView().getModel("oJsonModel");
			var msg = [{
				"Id": "ABC",
				"Type": "S",
				"Message": "Record is saved successfully"
			}];
			oJsonModel.setProperty("/oMessage", msg);

			var massAdd = [];
			oJsonModel.setProperty("/MassRegSet", massAdd);
		},
		herculis: function(oEvent) {
			debugger;
			var selectedIndex = oEvent.getParameter("arguments").listIndex;
			switch (selectedIndex) {
				case "1":
					this.getView().byId("sIdFilterSearch").setVisible(true);
					this.getView().byId("sIdPanelStdSearch").setVisible(true);
					this.getView().byId("sIdPanelAllStudents").setVisible(false);
					this.getView().byId("btnSearch").setVisible(false);
					this.getView().byId("btnRegSave").setVisible(false);
					this.getView().byId("btnMassRegSave").setVisible(false);
					this.getView().byId("sIdState_input").setValue("All");
					this.getView().byId("sIdCity_input").setValue("All");
					break;
				case "2":
					this.getView().byId("sIdFilterSearch").setVisible(false);
					this.getView().byId("sIdPanelStdSearch").setVisible(false);
					this.getView().byId("sIdPanelAllStudents").setVisible(true);
					this.getView().byId("btnSearch").setVisible(true);
					this.getView().byId("btnRegSave").setVisible(false);
					this.getView().byId("btnMassRegSave").setVisible(false);

					var oJsonModel = this.getOwnerComponent().getModel("oJsonModel");
					var oDataModel = this.getView().getModel();
					// this.Busydialog.open();
					var that = this;
					oDataModel.read("/StateSet", {
						urlParameters: {
							"$expand": "To_City"
						},
						async: false,
						success: function(oData) {
							// debugger;
							// that.fnCloseBusyDialog();
							oJsonModel.setProperty("/StateSet", oData.results);
							oJsonModel.setProperty("/CitySet", oJsonModel.getProperty("/StateSet")[0].To_City.results);
						},
						error: function(error) {
							debugger;
						}
					});

					break;
			}
		},
		fnOpenBusyDialog: function(oEvent) {
			var that = this;
			if (!that.Busydialog) {
				that.Busydialog = sap.ui.xmlfragment("ibm.fin.ar.fragments.BusyDialog", this);
				that.getView().addDependent(this.Busydialog);
			}
			jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this.Busydialog);
			that.Busydialog.open();
		},

		fnCloseBusyDialog: function(oEvent) {
			var that = this;
			that.Busydialog.close();
		},
		onHide: function() {
			this.getView().getParent().getParent().setMode("HideMode");
			this.getView().byId("btnShow").setVisible(true);
			this.getView().byId("btnHide").setVisible(false);
		},
		onShow: function() {
			this.getView().getParent().getParent().setMode("ShowHideMode");
			this.getView().byId("btnShow").setVisible(false);
			this.getView().byId("btnHide").setVisible(true);
		},
		OnPressgo: function(oEvent) {
			debugger;
			var oDataModel = this.getView().getModel();
			var oTable = this.getView().byId("idTable_std");
			var that = this;
			var aFilters = [];
			var sRoll = this.getView().byId("sIdRoll_input").getValue();
			if (sRoll !== "") {
				var oFilter1 = new sap.ui.model.Filter("Roll", sap.ui.model.FilterOperator.EQ, sRoll);
				aFilters.push(oFilter1);
			}
			var sName = this.getView().byId("sIdName_input").getValue();
			if (sName !== "") {
				var oFilter2 = new sap.ui.model.Filter("Fname", sap.ui.model.FilterOperator.Contains, sName);
				aFilters.push(oFilter2);
			}
			var sState = this.getView().byId("sIdState_input").getValue();
			if (sState !== "" && sState !== "All") {
				var oFilter3 = new sap.ui.model.Filter("State", sap.ui.model.FilterOperator.Contains, sState);
				aFilters.push(oFilter3);
			}
			var sCity = this.getView().byId("sIdCity_input").getValue();
			if (sCity !== "" && sCity !== "All") {
				var oFilter4 = new sap.ui.model.Filter("City", sap.ui.model.FilterOperator.Contains, sCity);
				aFilters.push(oFilter4);
			}
			if (aFilters.length !== 0) {
				this.fnOpenBusyDialog();
				oDataModel.read("/StudentsSet", {
					async: false,
					filters: aFilters,
					success: function(oData) {
						debugger;
						if (oData.results.length === 0) {
							var oJsonModel = new sap.ui.model.json.JSONModel(oData);
							oJsonModel.setSizeLimit(500);
							oTable.setModel(oJsonModel);
							that.fnCloseBusyDialog();
							sap.m.MessageBox.show(
								"No Data Found !",
								sap.m.MessageBox.Icon.ERROR, "Error");
							return;
						} else {
							oJsonModel = new sap.ui.model.json.JSONModel(oData);
							oJsonModel.setSizeLimit(500);
							oTable.setModel(oJsonModel);
							that.fnCloseBusyDialog();
						}
					},
					error: function(Error) {
						debugger;
						that.fnCloseBusyDialog();
					}

				});
			} else {
				this.fnOpenBusyDialog();
				oDataModel.read("/StudentsSet", {
					success: function(oData) {
						debugger;
						if (oData.results.length === 0) {
							// that.fnCloseBusyDialog();
							sap.m.MessageBox.show(
								"No Data Found !",
								sap.m.MessageBox.Icon.ERROR, "Error");
							return;
						} else {
							var len = oData.results.length;
							for (var i = 0; i < len;) {
								if (oData.results[i].Fname === "") {
									oData.results.splice(i, 1);
									// i++;
									len = len - 1;
								} else {
									i++;
								}
							}
							var oJsonModel = new sap.ui.model.json.JSONModel(oData);
							oJsonModel.setSizeLimit(500);
							oTable.setModel(oJsonModel);
							that.fnCloseBusyDialog();
						}
					},
					error: function(Error) {
						debugger;
					}

				});
			}
		},

		onF4State: function(oEvent) {
			debugger;
			this.fnOpenBusyDialog();
			var oJsonModel = this.getOwnerComponent().getModel("oJsonModel");
			var oDataModel = this.getView().getModel();
			// var oTable = this.getView().byId("idTable_std");
			if (!this._valueHelpDialog) {
				var that = this;
				oDataModel.read("/StateSet", {
					urlParameters: {
						"$expand": "To_City"
					},
					async: false,
					success: function(oData) {
						debugger;
						that.fnCloseBusyDialog();
						oJsonModel.setProperty("/StateSet", oData.results);
					},
					error: function(error) {
						debugger;
					}
				});

				// if (!this._valueHelpDialog) {
				this._valueHelpDialog = sap.ui.xmlfragment(
					"ibm.fin.ar.fragments.StateSuggestion",
					this
				);
				this._valueHelpDialog.bindAggregation("items", {
					path: "oJsonModel>/StateSet",
					// sorter: oSorter,
					template: new sap.m.StandardListItem({
							title: "{oJsonModel>Sname}"
						})
						// For DisplayListItem            					
						// template: new sap.m.DisplayListItem({
						// 	label: "{oJsonModel>Sname}",
						// 	value: "{oJsonModel>Sid}"
						// })

				});
				this.getView().addDependent(this._valueHelpDialog);
				this._valueHelpDialog.setTitle("State Name");
			}
			this.fnCloseBusyDialog();
			this._valueHelpDialog.open();

		},
		_handleValueHelpConfirm: function(oEvent) {
			if (oEvent.getSource().getTitle() === "State Name") {
				var selectedItem = oEvent.getParameter("selectedItem").getTitle();
				if (selectedItem) {
					var oStateInput = this.getView().byId("sIdState_input");
					oStateInput.setValue(selectedItem);

					this.getView().byId("sIdCity_input").setValue("All");
				}
			} else if (oEvent.getSource().getTitle() === "City Name") {
				var selectedItem = oEvent.getParameter("selectedItem").getTitle();
				if (selectedItem) {
					var oCityInput = this.getView().byId("sIdCity_input");
					oCityInput.setValue(selectedItem);
				}
			}
		},
		onF4City: function(oEvent) {
			debugger;
			var oJsonModel = this.getView().getModel("oJsonModel");
			var stateName = this.getView().byId("sIdState_input").getValue();
			if (stateName === "") {
				MessageToast.show("Pleas select State");
				return;
			}
			for (var i = 0; i < oJsonModel.oData.StateSet.length; i++) {
				if (oJsonModel.oData.StateSet[i].Sname === stateName) {
					oJsonModel.setProperty("/CitySet", oJsonModel.oData.StateSet[i].To_City.results);
					break;
				}
			}
			// OR
			// var Sname = oJsonModel.oData.StateSet.find(record => record.Sname === stateName);
			// oJsonModel.setProperty("/CitySet", Sname.To_City.results);

			if (!this._valueHelpDialog1) {
				this._valueHelpDialog1 = sap.ui.xmlfragment(
					"ibm.fin.ar.fragments.StateSuggestion",
					this
				);
				this._valueHelpDialog1.bindAggregation("items", {
					path: "oJsonModel>/CitySet",
					// sorter: oSorter,
					template: new sap.m.StandardListItem({
						title: "{oJsonModel>Cname}"
					})
				});
				this.getView().addDependent(this._valueHelpDialog1);
				this._valueHelpDialog1.setTitle("City Name");
			}
			// this.fnCloseBusyDialog();
			this._valueHelpDialog1.open();
		},
		onSearch: function(oEvent) {
			debugger;
			var oDataModel = this.getView().getModel();
			var oJsonModel1 = this.getView().getModel("oJsonModel");
			var oTable = this.getView().byId("idTableAllStudents");
			var that = this;
			this.fnOpenBusyDialog();
			oDataModel.read("/StudentsSet", {
				success: function(oData) {
					if (oData.results.length === 0) {
						var oJsonModel = new sap.ui.model.json.JSONModel(oData);
						oJsonModel.setSizeLimit(500);
						oTable.setModel(oJsonModel);
						that.fnCloseBusyDialog();
						sap.m.MessageBox.show(
							"No Data Found !",
							sap.m.MessageBox.Icon.ERROR, "Error");
						return;
					} else {
						// oJsonModel = new sap.ui.model.json.JSONModel(oData);
						// oJsonModel.setSizeLimit(500);
						// oTable.setModel(oJsonModel);
						oJsonModel1.setProperty("/StudentsSet", oData.results);
						that.fnCloseBusyDialog();
						oTable.getBinding("items").filter([]);
						that.getView().byId("SelectState").setSelectedKey("0");
						that.getView().byId("SelectCity").setSelectedKey("0");
					}
				},
				error: function(Error) {
					debugger;
					that.fnCloseBusyDialog();
				}
			});
		},
		OnChangeState: function(oEvent) {
			debugger;
			var oJsonModel = this.getView().getModel("oJsonModel");
			var oTable = this.getView().byId("idTableAllStudents");
			var slectedState = oEvent.getParameter("selectedItem").getText();
			if (slectedState === "") {
				MessageToast.show("Pleas select State");
				return;
			}
			for (var i = 0; i < oJsonModel.oData.StateSet.length; i++) {
				if (oJsonModel.oData.StateSet[i].Sname === slectedState) {
					if (oJsonModel.oData.StateSet[i].To_City.results[0].Cname !== "All") {
						oJsonModel.oData.StateSet[i].To_City.results.unshift({
							"Cid": "0",
							"Cname": "All"
						});
					}
					oJsonModel.setProperty("/CitySet", oJsonModel.oData.StateSet[i].To_City.results);
					break;
				}
			}
			if (slectedState === "All") {
				oTable.getBinding("items").filter([]);
			} else {
				var oFilter = new sap.ui.model.Filter("State", sap.ui.model.FilterOperator.Contains, slectedState);
				oTable.getBinding("items").filter([oFilter]);
			}
			this.getView().byId("SelectCity").setSelectedKey("0");
		},
		OnChangeCity: function(oEvent) {
			debugger;
			var aFilters = [];
			// var oJsonModel = this.getView().getModel("oJsonModel");
			var slectedCity = oEvent.getParameter("selectedItem").getText();
			var slectedState = this.getView().byId("SelectState")._getSelectedItemText();
			var oTable = this.getView().byId("idTableAllStudents");
			if (slectedCity !== "All") {
				var oFilter = new sap.ui.model.Filter("State", sap.ui.model.FilterOperator.Contains, slectedState);
				aFilters.push(oFilter);
				var oFilter1 = new sap.ui.model.Filter("City", sap.ui.model.FilterOperator.Contains, slectedCity);
				aFilters.push(oFilter1);
				oTable.getBinding("items").filter(aFilters);
			} else {
				oFilter = new sap.ui.model.Filter("State", sap.ui.model.FilterOperator.Contains, slectedState);
				aFilters.push(oFilter);
				oTable.getBinding("items").filter(aFilters);
			}
		},
		onSelectionChaneStd: function(oEvent) {
			debugger;
			var oJsonModel = this.getView().getModel("oJsonModel");
			if (oEvent.getParameters("section").section.mProperties.title === "All Students") {
				this.getView().byId("btnSearch").setVisible(true);
				this.getView().byId("btnRegSave").setVisible(false);
				this.getView().byId("btnMassRegSave").setVisible(false);
			} else if (oEvent.getParameters("section").section.mProperties.title === "RegistrationStd") {
				this.getView().byId("btnSearch").setVisible(false);
				this.getView().byId("btnRegSave").setVisible(true);
				this.getView().byId("btnMassRegSave").setVisible(false);

				var studentData = {
					"Roll": "",
					"Fname": "",
					"Lname": "",
					"Class": "",
					"Dob": "",
					"Sex": "",
					"Contact": "",
					"State": "",
					"City": ""
				};

				oJsonModel.setProperty("/StudentReg", studentData);
				this.getView().byId("sIdStudentsimpleform").rerender();

			} else if (oEvent.getParameters("section").section.mProperties.title === "Mass Registration") {
				this.getView().byId("btnSearch").setVisible(false);
				this.getView().byId("btnRegSave").setVisible(false);
				this.getView().byId("btnMassRegSave").setVisible(true);

				var classstd = [{
					"cId": "8",
					"Class": "8th"
				}, {
					"cId": "9",
					"Class": "9th"
				}, {
					"cId": "10",
					"Class": "10th"
				}, {
					"cId": "11",
					"Class": "12th"
				}];
				oJsonModel.setProperty("/ClassSet", classstd);

				var gender = [{
					"gId": "M",
					"gen": "Male"
				}, {
					"gId": "F",
					"gen": "Female"
				}];
				oJsonModel.setProperty("/GenderSet", gender);
			}
		},
		// ***************************************************************************************
		//						MessagePopover: Start
		// ***************************************************************************************
		createMessagePopover: function(oEvent) {
			var that = this;
			debugger;
			// var oJsonModel = that.getOwnerComponent().getModel("oJsonModel");
			// var oJsonModel = that.getView().getModel("oJsonModel");
			// var msg = [{
			// 	"Id": "ABC",
			// 	"Type": "S",
			// 	"Message": "Record is saved successfully"
			// }];
			// oJsonModel.setProperty("/oMessage", msg);

			this.oMP = new sap.m.MessagePopover({
				items: {
					path: "oJsonModel>/oMessage",
					template: new sap.m.MessageItem({
						title: {
							parts: [{
								path: 'oJsonModel>Message'
							}]
						},
						type: {
							parts: [{
								path: 'oJsonModel>Type'
							}],
							formatter: this.msgType
						},
						description: ""
					})
				}
			});
			this.getView().byId("messages").addDependent(this.oMP);
			this.oMP.openBy(this.getView().byId("messages"));
		},
		msgType: function(messageType) {
			switch (messageType) {
				case "E":
					messageType = "Error";
					break;
				case "S":
					messageType = "Success";
					break;
				case "I":
					messageType = "Information";
					break;
				case "W":
					messageType = "Warning";
					break;
			}
			return messageType;
		},
		handleMessagePopoverPress: function(oEvent) {
			if (!this.oMP) {
				this.createMessagePopover();
			}
			this.oMP.toggle(oEvent.getSource());

		},
		// ***************************************************************************************
		//						MessagePopover: Start
		// ***************************************************************************************
		onRegSave: function(oEvent) {
			debugger;
			var payload = this.getView().getModel("oJsonModel").getProperty("/StudentReg");
			var yourDate = this.getView().byId("DP2").getValue();
			yourDate = yourDate.slice(6) + "/" + yourDate.slice(3, 5) + "/" + yourDate.slice(0, 2);
			var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
				pattern: "yyyy-MM-dd"
			});
			var oDate = dateFormat.format(new Date(yourDate));
			oDate = oDate + "T00:00:00";
			payload.Dob = oDate;
			var oDataModel = this.getView().getModel();
			var that = this;
			this.fnOpenBusyDialog();
			oDataModel.create("/StudentsSet", payload, {
				success: function(response) {
					debugger;

					// MessageBox.show("Record is saved successfully!!!");
					// var oJsonModel = that.getOwnerComponent().getModel("oJsonModel");
					// var msg = [{
					// 	"Id": "ABC",
					// 	"Type": "S",
					// 	"Message": "Record is saved successfully"
					// }];
					// oJsonModel.setProperty("/oMessage", msg);
					that.createMessagePopover();
					that.fnCloseBusyDialog();
				},
				error: function(oError) {
					debugger;
					that.fnCloseBusyDialog();
					MessageToast.show(JSON.parse(oError.responseText).error.message.value);
				}
			});
		},
		OnPressEdit: function(oEvent) {
			debugger;
			// oEvent.getSource().getParent().getAggregation("cells")[0].getProperty("text")
			// "5"
			// oEvent.getSource().getParent().getAggregation("cells")[1].getProperty("text")
			// "Shanjiv Yadav"
			var oJsonModel = this.getView().getModel("oJsonModel");
			var slectedState;
			var roll = oEvent.getSource().getParent().getAggregation("cells")[0].getProperty("text");
			for (var i = 0; i < this.getView().getModel("oJsonModel").oData.StudentsSet.length; i++) {
				if (this.getView().getModel("oJsonModel").oData.StudentsSet[i].Roll === roll) {
					oJsonModel.setProperty("/StudentReg", this.getView().getModel("oJsonModel").oData.StudentsSet[i]);
					slectedState = this.getView().getModel("oJsonModel").oData.StudentsSet[i].State;
					break;
				}
			}
			for (i = 0; i < oJsonModel.oData.StateSet.length; i++) {
				if (oJsonModel.oData.StateSet[i].Sname === slectedState) {
					oJsonModel.setProperty("/CitySet", oJsonModel.oData.StateSet[i].To_City.results);
					break;
				}
			}

			this.getView().byId("btnSearch").setVisible(false);
			this.getView().byId("btnRegSave").setVisible(true);
			// Change selection Tab
			this.oObjectPageLayout = this.getView().byId("ObjectPageLayoutStudent");
			this.oEditAttrSection = this.getView().byId("ObjectPageSectionStudentReg");
			this.oObjectPageLayout.setSelectedSection(this.oEditAttrSection.getId());
			this.getView().byId("sIdStudentsimpleform").rerender();
		},
		onAddNewRow: function(oEvent) {
			debugger;
			var oJsonModel = this.getOwnerComponent().getModel("oJsonModel");
			var oTableMassReg = this.getView().byId("idTableMassReg");
			var oModelPre = oTableMassReg.getModel("oJsonModel").getProperty("/MassRegSet");

			var ONewObjectStd = {
				"Roll": "",
				"Fname": "",
				"Lname": "",
				"Class": "",
				"Dob": new Date(),
				"Sex": "",
				"Contact": "",
				"State": "",
				"City": ""
			};

			oModelPre.push(ONewObjectStd);
			oTableMassReg.getModel("oJsonModel").setProperty("/MassRegSet", oModelPre);
			this.getView().byId("idTableMassReg").removeSelections(true);
			oJsonModel.refresh(true);
			oTableMassReg.getModel("oJsonModel").refresh();
			// debugger
		},
		onMassRegSave: function(oEvent) {
			debugger;
			var that = this;
			var oJsonModel = this.getOwnerComponent().getModel("oJsonModel");
			// var oJSONModel = new sap.ui.model.json.JSONModel();
			// this.getView().setModel
			var allStudents = this.getView().getModel("oJsonModel").getProperty("/MassRegSet");
			// var retrn = [];
			var payload = {
				"Option": "All",
				"ToStudents": allStudents,
				"ToReturns": []
			};

			var oDataModel = this.getView().getModel();
			var that = this;
			this.fnOpenBusyDialog();
			oDataModel.create("/MassRegistrationSet", payload, {
				success: function(response) {
					debugger;
					oJsonModel.setProperty("/oMessage", response.ToReturns.results);
					that.createMessagePopover();
					that.fnCloseBusyDialog();
				},
				error: function(oError) {
					debugger;
					that.fnCloseBusyDialog();
					MessageToast.show(JSON.parse(oError.responseText).error.message.value);
				}
			});

		}

		/** 
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf ibm.fin.ar.view.Home
		 */
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf ibm.fin.ar.view.Home
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf ibm.fin.ar.view.Home
		 */
		//	onExit: function() {
		//
		//	}

	});

});