sap.ui.define([
	"ibm/fin/ar/controller/BaseController",
	"sap/m/GroupHeaderListItem"
], function(Controller, GroupHeaderListItem) {
	"use strict";

	return Controller.extend("ibm.fin.ar.controller.View1", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf ibm.fin.ar.view.View1
		 */
		onInit: function() {
			this.oRouter = this.getOwnerComponent().getRouter();
			this.oRouter.attachRoutePatternMatched(this.herculis, this);
			var List = [{
				"Title": "Students",
				"Desc": "Search Students",
				"key": "sIdCUCPIRDAdditionaldecl",
				"CategoryId": 1
			}, {
				"Title": "Students",
				"Desc": "All Students",
				"key": "sIdAllStu",
				"CategoryId": 2
			}, {
				"Title": "Students",
				"Desc": "Registration",
				"key": "sIdReg",
				"CategoryId": 3
			}, {
				"Title": "Students",
				"Desc": "Current Enrolment",
				"key": "sIdCurEnr",
				"CategoryId": 4
			}, {
				"Title": "Students",
				"Desc": "Previuos Enrolments",
				"key": "sIdPreEnr",
				"CategoryId": 5
			}, {
				"Title": "Students",
				"Desc": "Fees",
				"key": "sIdFee",
				"CategoryId": 6
			}, {
				"Title": "Students",
				"Desc": "Attendance",
				"key": "sIdAtt",
				"CategoryId": 7
			}, {
				"Title": "Classes",
				"Desc": "Add Subject",
				"key": "sIdAddSub",
				"CategoryId": 8
			}, {
				"Title": "Classes",
				"Desc": "Create Class",
				"key": "sIdCreCla",
				"CategoryId": 9
			}, {
				"Title": "Enrolments",
				"Desc": "Enrol Student",
				"key": "sIdEnrStu",
				"CategoryId": 10
			}, {
				"Title": "Enrolments",
				"Desc": "Enrol Bulk Students",
				"key": "sIdEnrBul",
				"CategoryId": 11
			}];
			var masterdata = new sap.ui.model.json.JSONModel(List);
			this.getView().byId("IdSlist").setModel(masterdata, "master");

			this.getView().byId("IdSlist").setVisible(false);
			this.getView().byId("idBtnPrd").setVisible(false);
		},
		herculis: function(oEvent) {
			debugger;
			var selectedIndex = oEvent.getParameter("arguments").myVar;
			var oList = this.getView().byId("myList");
			var allItems = oList.getItems();
			oList.setSelectedItem(allItems["/" + selectedIndex]);
			// oList.setSelectedContextPaths("/" + selectedIndex);
			// this.getView().bindElement("/fruits/" + selectedIndex);

			//Heading the data manually
			// debugger;
			var that = this;
			var oDataModel = this.getView().getModel();
			oDataModel.read("/ProductSet('HT-1000')", {
				success: function(data) {
					// alert(" Read Success");
					// console.log(data);
					var oLocal = new sap.ui.model.json.JSONModel();
					oLocal.setData({
						mydata: data
					});
					that.getView().setModel(oLocal, "zkas");
				},
				error: function(Error) {
					alert(" Read Error");
					// console.log(Error);
				}
			});
		},
		onNext: function(myIndex) {
			/*//Get the mother object of this view
			var oApp = this.getView().getParent();
			//Use the mother view to call another view
			oApp.to("idView2","flip");*/
			this.oRouter.navTo("oberoy", {
				myVar: myIndex
			});
		},
		onStudent: function() {
			this.getView().byId("myList").setVisible(false);
			this.getView().byId("mySearch").setVisible(false);
			this.getView().byId("idBtnPrd").setVisible(true);
			this.getView().byId("idBtnStd").setVisible(false);
			this.getView().byId("IdSlist").setVisible(true);
			this.oRouter.navTo("Home",{
				listIndex: 0
			});
		},
		onProduct: function() {
			this.getView().byId("myList").setVisible(true);
			this.getView().byId("mySearch").setVisible(true);
			this.getView().byId("idBtnPrd").setVisible(false);
			this.getView().byId("idBtnStd").setVisible(true);
			this.getView().byId("IdSlist").setVisible(false);
			// this.oRouter.navTo("View1");
			this.onNext(1);
		},
		onItemPress: function(oEvent) {
			// this.onNext();
			var addressOfSelectedItem = oEvent.getParameter("listItem").getBindingContextPath();

			// var myIndex = addressOfSelectedItem.split("/")[addressOfSelectedItem.split("/").length - 1];
			this.onNext(addressOfSelectedItem.replace("/", ""));

			/*	//Get the mother object of of both brothers
				var oApp = this.getView().getParent().getParent();
				//Get the second child of the mother (brother 2).
				var oView2 = oApp.getDetailPages()[0];
				//bind the address of selected item to whole of view2.
				oView2.bindElement(addressOfSelectedItem);*/
		},
		onDelete: function(oEvent) {
			var itemToBeDeleted = oEvent.getParameter("listItem");
			// var oList = this.getView().byId("myList");
			// OR
			var oList = oEvent.getSource();
			oList.removeItem(itemToBeDeleted);
		},
		onSearch: function(oEvent) {
			var valueEnteredByUserOnScreen = oEvent.getParameter("query");
			//If we want ot search while type should filter, Add "if" lines
			// if (!valueEnteredByUserOnScreen) {
			// 	valueEnteredByUserOnScreen = oEvent.getParameter("newValue");
			// }
			//Filter Object- it used to filter the data from the model
			var oFilter1 = new sap.ui.model.Filter(
				"CATEGORY",
				sap.ui.model.FilterOperator.Contains,
				valueEnteredByUserOnScreen);
			// var oFilter2 = new sap.ui.model.Filter(
			// 	"type",
			// 	sap.ui.model.FilterOperator.Contains,
			// 	valueEnteredByUserOnScreen);
			// var aFilter = [oFilter1, oFilter2]; //AND operator by default
			var oFilter = new sap.ui.model.Filter({
				filters: [oFilter1], //oFilter2],
				and: false
			});
			var aFilter = [oFilter];
			var oList = this.getView().byId("myList");
			oList.getBinding("items").filter(aFilter);
		},
		onMostExp: function() {
			//Step 1:Get the odata model object
			var oDataModel = this.getView().getModel();
			var that = this;
			//Step 2:call function import
			oDataModel.callFunction("/GetMostExpensiveProduct", {
				//Step 3:Handle call back
				success: function(result) {
					debugger;
					//Step 4:Create dynamic popup
					var oModel = new sap.ui.model.json.JSONModel();
					oModel.setData(result);
					that.getView().setModel(oModel, "myExp");
					var that2 = that;
					//AMD - Asynchronous Module Definition to load dynamic dependencies
					//When we need, then we load, because user may/may not click on this button
					// for most exp product.
					sap.ui.require(["sap/m/Dialog",
							"sap/ui/layout/form/SimpleForm",
							"sap/m/Label",
							"sap/m/Text",
							"sap/m/Button"
						],
						function(Dialog, SimpleForm, Label, TextField, Button) {
							//Create a brand new Dialog control (popup in Fiori)
							var oDialog = new Dialog({
								title: "Most Expensive Item",
								contentWidth: "600px",
								beginButton: new Button({
									text: "Close",
									press: function(oEvent) {
										oEvent.getSource().getParent().close();
										//OR
										//oDialog.close();
									}
								})
							});
							//Create a brand new simple form
							var oSimple = new SimpleForm({
								content: [
									new Label({
										text: "Product Id"
									}),
									new TextField({
										text: "{myExp>/PRODUCT_ID}"
									}),
									new Label({
										text: "Name"
									}),
									new TextField({
										text: "{myExp>/NAME}"
									}),
									new Label({
										text: "Price"
									}),
									new TextField({
										text: "{myExp>/PRICE} {myExp>CURRENCY_CODE}"
									})
								]
							});
							//Add Simple form inside dialog
							oDialog.addContent(oSimple);
							//Set the model to dialog so that it can show data.
							//Step 5:Bind the data to dynamic popup								
							oDialog.setModel(that2.getView().getModel("myExp"), "myExp");
							//Step 6:Open the popup				
							oDialog.open();
						});

				},
				//Step 3:Handle call back
				error: function(oErr) {
					debugger;
				}
			});

		},
		grouper: function(oGroup) {

			return {
				key: oGroup.oModel.oData[oGroup.sPath.split("/")[1]].Title
			};
		},
		getGroupHeader: function(oGroup) {
				return new GroupHeaderListItem({
					title: oGroup.key,
					upperCase: false
				});
			},
			onItemPressStu: function(oEvent){
				debugger;
				var that = this;
				var sToPageId = oEvent.getParameter("listItem").getCustomData()[0].getValue();
				// this.getSplitContObj().toDetail(this.createId(sToPageId));

				var sListKey = oEvent.getSource()._oItemNavigation.getFocusedIndex();
				this.oRouter.navTo("Home", {
				listIndex: sListKey
			});
				
			}
			/**
			 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
			 * (NOT before the first rendering! onInit() is used for that one!).
			 * @memberOf ibm.fin.ar.view.View1
			 */
			//	onBeforeRendering: function() {
			//
			//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf ibm.fin.ar.view.View1
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf ibm.fin.ar.view.View1
		 */
		//	onExit: function() {
		//
		//	}

	});

});