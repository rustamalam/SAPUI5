sap.ui.define(
	["sap/ui/core/format/NumberFormat",
	 "sap/ui/core/format/DateFormat"],
	function(NumberFormat, DateFormat) {
		return {
			convertToCaps: function(inp) {
				if (inp) {
					return inp.toUpperCase();
				}
			},
			convertToBool: function(myInp) {
				var output = false;
				if (myInp === true || myInp === 'true') {
					output = true;
				} else {
					output = false;
				}
				return output;
			},
			// jionTwo: function(a,b){
			// 	return a + ' ' + b;
			// }
			// Using Standard formatter
			jionTwo: function(a, b) {
				var oCurrencyFormat = NumberFormat.getCurrencyInstance();

				return oCurrencyFormat.format(a, b); // output: EUR 12,345.68
			},
			convertDateFormate: function(doj) {
				debugger;
				var myDate = new Date(doj);
				var oDateFormat = DateFormat.getDateInstance({
					pattern: "dd/MM/yyy"
				});
				var dateFormatted = oDateFormat.format(myDate);
				// // var output = myDate.getDate() + "\\" +  (myDate.getMonth()+1) + "\\" + myDate.getFullYear();
				// if (typeof(doj) != 'undefined' && doj != null){
				// var output = doj.substring(6,8) + "." + doj.substring(4,6) + "." + doj.substring(0,4);
				// }
				return dateFormatted;
			}
		};
	}
);