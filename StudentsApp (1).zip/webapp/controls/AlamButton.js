sap.ui.define(
	["sap/m/Button"],
	function(oBtn) {
		oBtn.extend("ibm.fin.ar.controls.AlamButton", {
			metadata: {
				properties: {},
				events: {
					"hover": {}
				}
			},
			onmouseover: function() {
				this.fireHover();
			},
			renderer: {}
		});
	});