sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel"	], 
	function(Controller, JSONModel) {
	"use strict";

	return Controller.extend("alam.controller.Main", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf alam.view.Main
		 */
			onInit: function() {
				var mySampleData = {
							"empStr":{
								"eNo": 1000,
								"eName": "Alam",
								"salary": 70000,
								"currency": "USD",
								"mario": true
							},
							"empTable": []
					};
					// How to set Model at application level.
					//Step1: Create a brand new model object
					var oModel = new JSONModel();
					//Step2: Set/load the data inside model
					oModel.setData(mySampleData);
					//Step3: Make the model aware to the app.
					sap.ui.getCore().setModel(oModel);
		
			},
			onMagic: function(){
					//How to set the data for JSON properies.
					//Step: Get the model obect.
					var oModel = sap.ui.getCore().getModel();
					//Step2: Inside the model object set the data of mario property to false.
					oModel.setProperty("/empStr/mario",false);
				},
			onShowHide: function(){
				var check = sap.ui.getCore().byId("__form1--Form").getVisible();
				if(check === true){
					sap.ui.getCore().byId("__form1--Form").setVisible(false);
				}else{
					sap.ui.getCore().byId("__form1--Form").setVisible(true);
				}
			}

		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf alam.view.Main
		 */
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf alam.view.Main
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf alam.view.Main
		 */
		//	onExit: function() {
		//
		//	}

	});

});