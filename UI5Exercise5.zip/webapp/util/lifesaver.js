sap.ui.define(
	["sap/ui/core/format/NumberFormat"], 
	function(NumberFormat){
		return{
			convertToCaps: function(inp){
				if(inp){
					return inp.toUpperCase();
				}
			},
			convertToBool: function(myInp){
				var output = false;
				if(myInp === true || myInp === 'true' ){
					output = true;
				}else{
					output = false;
				}
				return output;
			},
			// jionTwo: function(a,b){
			// 	return a + ' ' + b;
			// }
			// Using Standard formatter
			jionTwo: function(a,b){
				var oCurrencyFormat = NumberFormat.getCurrencyInstance();

				return oCurrencyFormat.format(a, b); // output: EUR 12,345.68
			}
		};
	}
);