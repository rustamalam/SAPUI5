sap.ui.define(
	["sap/ui/core/Control"], 
	function(Control){
		Control.extend("ibm.fin.ar.controls.Heading",{	
			//All the properties, events, methods, aggregation are define in metadata.
			metadata:{
				properties:{
					"text":"",
					"color":"",
					"border":""
				}
			},
			//If we want to initialize some value to these properties, we will use the init method:- initialization method.
			init:function(){
				this.setColor("blue");
			},
			//renderer is going to produce the equivalent HTML for custom code,
			//oRom: Renderer manager which will talk to browser.
			//oControl- Which is the object of the custom control itself, using this we can access metadata if the UI control.
			renderer: function(oRm,oControl){
				// oRm.write("<h1 style ='color:" + oControl.getColor() + "'>" + oControl.getText() + "</h1>");
				oRm.write("<h1");
				oRm.addStyle("color", oControl.getColor());
				oRm.addStyle("border", oControl.getBorder());
				oRm.writeStyles();
				oRm.write(">" + oControl.getText() + "</h1>");
			}
			
		});
}); 