sap.ui.define([
	"alam/controller/BaseController",
	"alam/model/models"
], function(Controller, myModel) {
	"use strict";

	return Controller.extend("alam.controller.Main", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf alam.view.Main
		 */
		onInit: function() {
			var oModel = myModel.createJSONModel("model/mockData/myData.json");
			var oModel1 = myModel.createJSONModel("model/mockData/myData2.json");
			// Step3: Make the model aware to the app.
			sap.ui.getCore().setModel(oModel);
			sap.ui.getCore().setModel(oModel1, "walla");
			// this.getView().byId("idSal").bindValue("/empStr/salary");
			// this.getView().byId("idCurr").bindProperty("value", "/empStr/currency");
			Controller.x = "model1";
		},
		onFlip: function(){
			var oModel = sap.ui.getCore().getModel();
			var oModel1 = sap.ui.getCore().getModel("walla");
			sap.ui.getCore().setModel(oModel1);
			sap.ui.getCore().setModel(oModel, "walla");
			
		}
		

		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf alam.view.Main
		 */
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf alam.view.Main
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf alam.view.Main
		 */
		//	onExit: function() {
		//
		//	}

	});

});