sap.ui.define(
	["sap/ui/core/mvc/Controller"], 
	function(Controller){
		var flag = 'model1';
		return Controller.extend("alam.controller.BaseController", {
			// var flag = true;
		});
});