sap.ui.define(
	["sap/ui/model/json/JSONModel"],
	function(JSONModel) {
		return {
			createJSONModel: function(addressOfDataFile) {
				//Step1: Create a brand new model object
				var oModel = new JSONModel();
				//Step2: Set/load the data inside model
				oModel.loadData(addressOfDataFile);
				//Step3: Return this model object out
				return oModel;
			}
		};
	});