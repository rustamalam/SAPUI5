sap.ui.define(
	["sap/ui/core/UIComponent"],
	function(UIComponent){
		return UIComponent.extend("ibm.fin.ar.Component",{
			metadata: {},
			init: function(){
				//invoke the parent class constructor. 
				sap.ui.core.UIComponent.prototype.init.apply(this);
			},
			createContent: function(){
				var oView = new sap.ui.view("idView",{
					viewName: "ibm.fin.ar.view.App",
					type: sap.ui.core.mvc.ViewType.XML  //or "XML"
				});
				
				var oView1 = new sap.ui.view("idView1",{
					viewName: "ibm.fin.ar.view.View1",
					type: sap.ui.core.mvc.ViewType.XML  //or "XML"
				});
				
				var oView2 = new sap.ui.view("idView2",{
					viewName: "ibm.fin.ar.view.View2",
					type: sap.ui.core.mvc.ViewType.XML  //or "XML"
				});
				
				//obtain the app container which is inside app view
				var oMother = oView.byId("myApp");
				oMother.addPage(oView1);
				oMother.addPage(oView2);
				
				return oView;
			},
			destroy: function(){}
		});
	}
	);