sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function(Controller) {
	"use strict";

	return Controller.extend("alam.com.controller.Exercise", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf alam.com.view.Exercise
		 */
			onInit: function() {
			/*var oButton = sap.ui.getCore().byId("idBtn");
					oButton.setIcon("sap-icon://delete");*/
			},
		
		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf alam.com.view.Exercise
		 */
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf alam.com.view.Exercise
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf alam.com.view.Exercise
		 */
		//	onExit: function() {
		//
		//	}
		validation: function(){
			var valUser = sap.ui.getCore().byId("idUser").getValue();
			var valPwd = sap.ui.getCore().byId("idPwd").getValue();
			if(valUser === "Rustam" && valPwd === "alam"){
				alert("Login Successful");	
			}else{
				alert("Wrong User name  or Password");	
			}
				
		}

	});

});