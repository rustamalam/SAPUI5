sap.ui.jsview("alam.com.view.Exercise", {

	/** Specifies the Controller belonging to this View. 
	 * In the case that it is not implemented, or that "null" is returned, this View does not have a Controller.
	 * @memberOf alam.com.view.Exercise
	 */
	getControllerName: function() {
		return "alam.com.controller.Exercise";
	},

	/** Is initially called once after the Controller has been instantiated. It is the place where the UI is constructed. 
	 * Since the Controller is given to this method, its event handlers can be attached right away. 
	 * @memberOf alam.com.view.Exercise
	 */
	createContent: function(oController) {
		/*var oPage = new sap.m.Page({
			title: "Title",
			content: []
		});

		var app = new sap.m.App("myApp", {
			initialPage: "oPage"
		});
		app.addPage(oPage);
		return app;*/
		var oL1 = new sap.m.Label({text:"User Name"});
		var oL2 = new sap.m.Label({text:"Password"});
		var oInptUser = new sap.m.Input("idUser",{
			width: "200px"
		});
		var oInptPwd = new sap.m.Input("idPwd",{
			width: "200px",
			type: "Password"
		});
	/*	var odate = new sap.m.DatePicker("idDate", {
			width: "200px"
		});*/
		var oButton = new sap.m.Button("idBtn",{
			text: "Click me",
			press: [oController.validation, oController],
			icon: "sap-icon://employee",
			width: "120px"
		});
		/*var oSimpleForm = new sap.ui.layout.form.Simpleform({
			content: [oL1, oInptUser, oL2, oInptPwd, oButton]	
		});*/
		var oSimpleForm = new sap.ui.layout.form.SimpleForm({
			content: [oL1, oInptUser, oL2, oInptPwd, new sap.m.Label(), oButton] 
			
		});
		return oSimpleForm;
	}

});