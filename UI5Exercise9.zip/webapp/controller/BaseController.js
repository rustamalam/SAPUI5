sap.ui.define(
	["sap/ui/core/mvc/Controller"],
	function(Controller) {
		// var flag = 'model1';
		return Controller.extend("ibm.fin.ar.controller.BaseController", {
			// var flag = true;
		});
	});