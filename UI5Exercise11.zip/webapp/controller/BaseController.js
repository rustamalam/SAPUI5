sap.ui.define(
	["sap/ui/core/mvc/Controller",
	 "sap/m/MessageToast"],
	function(Controller,MessageToast) {
		// var flag = 'model1';
		return Controller.extend("ibm.fin.ar.controller.BaseController", {
			// var flag = true;
			someBaseMethod: function(){
				MessageToast.show("Wallah!! the fragment button code triggered");
		}
		});
	});