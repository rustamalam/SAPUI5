sap.ui.define([
	"ibm/fin/ar/controller/BaseController"
], function(Controller) {
	"use strict";

	return Controller.extend("ibm.fin.ar.controller.View1", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf ibm.fin.ar.view.View1
		 */
		onInit: function() {
			this.oRouter = this.getOwnerComponent().getRouter();
			//Whenever the route change, Its changed when browser back-forth or manually or select an item,
			this.oRouter.attachRoutePatternMatched(this.herculis, this);
			// this.oRouter.navTo("oberoy", {
			// 	myVar: 0
			// });
		},
		herculis: function(oEvent) {
			debugger;
			var selectedIndex = oEvent.getParameter("arguments").myVar;
			var oList = this.getView().byId("myList");
			var allItems = oList.getItems();
			oList.setSelectedItem(allItems[selectedIndex]);
			// this.getView().bindElement("/fruits/" + selectedIndex);
		},
		onNext: function(myIndex) {
			/*//Get the mother object of this view
			var oApp = this.getView().getParent();
			//Use the mother view to call another view
			oApp.to("idView2","flip");*/
			this.oRouter.navTo("oberoy", {
				myVar: myIndex
			});
		},
		onItemPress: function(oEvent) {
			// this.onNext();
			var addressOfSelectedItem = oEvent.getParameter("listItem").getBindingContextPath();

			var myIndex = addressOfSelectedItem.split("/")[addressOfSelectedItem.split("/").length - 1];
			this.onNext(myIndex);

			/*	//Get the mother object of of both brothers
				var oApp = this.getView().getParent().getParent();
				//Get the second child of the mother (brother 2).
				var oView2 = oApp.getDetailPages()[0];
				//bind the address of selected item to whole of view2.
				oView2.bindElement(addressOfSelectedItem);*/
		},
		onDelete: function(oEvent) {
			var itemToBeDeleted = oEvent.getParameter("listItem");
			// var oList = this.getView().byId("myList");
			// OR
			var oList = oEvent.getSource();
			oList.removeItem(itemToBeDeleted);
		},
		onSearch: function(oEvent) {
				var valueEnteredByUserOnScreen = oEvent.getParameter("query");
				//If we want ot search while type should filter, Add "if" lines
				if (!valueEnteredByUserOnScreen) {
					valueEnteredByUserOnScreen = oEvent.getParameter("newValue");
				}
				//Filter Object- it used to filter the data from the model
				var oFilter1 = new sap.ui.model.Filter(
					"name",
					sap.ui.model.FilterOperator.Contains,
					valueEnteredByUserOnScreen);
				var oFilter2 = new sap.ui.model.Filter(
					"type",
					sap.ui.model.FilterOperator.Contains,
					valueEnteredByUserOnScreen);
				// var aFilter = [oFilter1, oFilter2]; //AND operator by default
				var oFilter = new sap.ui.model.Filter({
					filters: [oFilter1, oFilter2],
					and: false
				});
				var aFilter = [oFilter];
				var oList = this.getView().byId("myList");
				oList.getBinding("items").filter(aFilter);
			}
			/**
			 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
			 * (NOT before the first rendering! onInit() is used for that one!).
			 * @memberOf ibm.fin.ar.view.View1
			 */
			//	onBeforeRendering: function() {
			//
			//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf ibm.fin.ar.view.View1
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf ibm.fin.ar.view.View1
		 */
		//	onExit: function() {
		//
		//	}

	});

});