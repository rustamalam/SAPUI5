sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function(Controller) {
	"use strict";

	return Controller.extend("ibm.fin.ar.controller.View1", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf ibm.fin.ar.view.View1
		 */
			onInit: function() {
		
			},
			onNext: function(){
				//Get the mother object of this view
			var oApp = this.getView().getParent();
			//Use the mother view to call another view
			oApp.to("idView2");
				
			},
			onItemPress: function(oEvent){
			var addressOfSelectedItem = oEvent.getParameter("listItem").getBindingContextPath();
			//Get the mother object of of both brothers
			var oApp = this.getView().getParent();
			//Get the second child of the mother (brother 2).
			var oView2 = oApp.getPages()[1];
			//bind the address of selected item to whole of view2.
			oView2.bindElement(addressOfSelectedItem);
			this.onNext();
			
			// oEvent.getParameter("listItem").getBindingContextPath()
				// "/fruits/1"
				// oEvent.getParameter("listItem").getTitle()
				// "Pomegranate"
				// this.getView().getModel().oData.fruits[0]
				// {…}
		}


		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf ibm.fin.ar.view.View1
		 */
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf ibm.fin.ar.view.View1
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf ibm.fin.ar.view.View1
		 */
		//	onExit: function() {
		//
		//	}

	});

});