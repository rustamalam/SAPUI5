sap.ui.define(
	["sap/ui/model/json/JSONModel",
	 "sap/ui/model/xml/XMLModel",
	 "sap/ui/model/resource/ResourceModel"], 
	function(JSONModel,XMLModel,ResourceModel){
		return {
			createJSONModel: function(addressOfDataFile){
				//Step1: Create a brand new model object
					var oModel = new JSONModel();
					//Step2: Set/load the data inside model
					oModel.loadData(addressOfDataFile);
					//Step3: Return this model object out
					return oModel;
			},
			createXMLModel: function(){
				var oModel = new XMLModel();
				oModel.loadData("model/mockData/myDemo.xml");
				return oModel;
			},
			createResourceModel: function(){
				var oModel = new ResourceModel({
					bundleUrl: "i18n/i18n.properties"
				});
				return oModel;
			}
		};
	
});