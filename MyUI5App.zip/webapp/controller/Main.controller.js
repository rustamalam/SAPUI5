sap.ui.define(
	["tom/controller/BaseController",
	 "tom/model/models",
	 "tom/util/lifesaver"], 
		function(Controller, myModel, lifeSaver){
			return Controller.extend("tom.controller.Main", {
				//Global variable.
				formatter: lifeSaver,

				onInit: function(){
					//Code for Inilitialization.
					// var mySampleData = ;
					// How to set Model at application level.
					var oModel = myModel.createJSONModel("model/mockData/myData.json");
					var oModel1 = myModel.createJSONModel("model/mockData/myData2.json");
					//By default Its twoway binding but we change with below syntax.
					// oModel.setDefaultBindingMode("OneWay");
					//Step3: Make the model aware to the app.
					sap.ui.getCore().setModel(oModel);
					sap.ui.getCore().setModel(oModel1, "walla");
					// this.getView().byId("idSal").bindValue("/empStr/salary");
					// this.getView().byId("idCurr").bindProperty("value", "/empStr/currency");
					//XML Model
					var oXMLModel = myModel.createXMLModel();
					sap.ui.getCore().setModel(oXMLModel);
					//Aggregation Binding through js coding
					// rows="{/empTab/row}" - This syntax for inside XML view
					// this.getView().byId("UITable").bindRows("/empTab/row");
					// OR
					   this.getView().byId("UITable").bindAggregation("rows", "/empTab/row");
					   
					 //Resource Model
					 var oResourceModel = myModel.createResourceModel();
					sap.ui.getCore().setModel(oResourceModel, "i18n");
				},
				onSelect: function(oEvent){
					debugger;
					//Step 1: Get the address of the memory of the selected row.
					var oContext = oEvent.getParameter("rowContext");
					var sPath = oContext.getPath();
					//Step 2: Bind the element to the simple form.
					var oSimple = this.getView().byId("idSimpleForm");
					oSimple.bindElement(sPath);
					
					// this.getView().byId("idSal").bindValue(sPath + "/salary");
					// this.getView().byId("idCurr").bindProperty("value", sPath + "/currency");
					// sap.ui.getCore().getModel().getProperty(sPath).eName -> Output: "Jenifer"
				},
				//Processing Logic
				displayVal: function(value){
					alert(value);
				},
				onMagic: function(){
					//How to set the data for JSON properies.
					//Step: Get the model obect.
					var oModel = sap.ui.getCore().getModel();
					//Step2: Inside the model object set the data of mario property to false.
					oModel.setProperty("/empStr/mario",false);
				},
				alam: function(){
					// alert("Welcome to UI5");
					// How to access here the value of Input field?
					// Step 1: get the object of the input field control: Note: UI5 object is not HTML object
					// Obtain the runtime instance of running application
					//Step 2: get the value of the field from the object
					/*var oCore = sap.ui.getCore();
					var oInput = oCore.byId("idUser");
					var val = oInput.getValue();*/
					// We can use chaining to reduce the line.e.g for above codes
					var val = sap.ui.getCore().byId("idUser").getValue();
					// alert(val);
					this.displayVal(val);
				},
				onAfterRendering: function(){
					debugger;
					$("#idMyXml--UITable-table tr:nth-child(odd)").css("background-color", "red");
				}
			});
});