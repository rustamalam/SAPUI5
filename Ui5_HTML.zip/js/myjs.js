function alamIsHere(){
				// alert('Welcome to Js');
				// console.log("This is console output");
				// document.write("<h1>Welcome to new page</h1>")
			}
			function validateInput(){
				var oUser = document.getElementById("user");
				var valUser = oUser.value;
				// var oPwd = document.getElementById("pwd");
				// var valPwd = oPwd.value;
				var valPwd = document.getElementById("pwd").value;
				if(valUser === "Rustam" && valPwd === "rustam"){
					document.write("user login successful");
				}else{
					var oLabel = document.getElementById("msg");
					oLabel.innerText = "An error occurred";
					startBlink();
				}
			}
			function startBlink(){
				$("#msg").fadeOut(500, function(){
					$("#msg").fadeIn(500, function(){
						startBlink();
					});
				});
			}
			function magic(){
				//Get all the elements with the same class name.
				var allBoxes = document.getElementsByClassName("box-content");
				// Loop over these elements together
				for(var i=0; i<allBoxes.length; i++){
					// change the style of each element within the loop.
					var eachElement = allBoxes[i];
					    eachElement.style.background = "black";
					    eachElement.style.color = "aqua";
					}
			}
			function loopOver(){
				setInterval(function(){
					console.log("The call function	was invoked");
				},5000);
				console.log("The loopOver function is completed");
			}
			function addDynamicElement(){
			var	oContainer = document.getElementById("dynpro");
				var newElement = document.createElement("h1");
				var textNode = document.createTextNode("Hello");
				newElement.appendChild(textNode);
				oContainer.appendChild(newElement);
			}
			
function changeCss(){
	$(".box-content").css("background","blue").css("color","red").css("font-family","cursive");	
}

function hideContent(){
	// $(".box").hide();
	// $(".box").fadeOut(5000);
	$(".box").fadeOut(5000, function(){
		alert("Hey Sir, We are done!!");
	});
}

function showContent(){
	// $(".box").show();
	$(".box").fadeIn(5000);
}

function animation(){
	$("input").animate({
		width: "25px",
		height: "10px"
	},function(){
		$("input").animate({
				width: "200px",
				height: "10px"	
		});
	});
}

function power(){
	$("#shoot").click(function(){
		alert("Shootted from 3mm Gun");	
	});
}